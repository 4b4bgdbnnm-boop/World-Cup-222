# WorldCupQuant AI

AI-powered FIFA World Cup betting intelligence platform — match analysis, EV scanning, AI bet builders, and live tournament tracking.

## Project Structure

```
worldcupquant/
├── apps/
│   ├── web/       # Next.js frontend + API routes
│   └── worker/    # Background jobs (odds polling, prediction refresh)
├── packages/
│   ├── db/        # Prisma schema, client, seed script
│   └── engine/    # Prediction model + EV/bet builder math
```

## Setup

### 1. Install dependencies

```bash
cd apps/web
npm install
```

### 2. Configure environment

Copy `.env.example` to `apps/web/.env` and fill in:
- `DATABASE_URL` — Postgres connection string (Supabase recommended)
- `ODDS_API_KEY` — from https://the-odds-api.com
- `ANTHROPIC_API_KEY` — from https://console.anthropic.com
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` / `CLERK_SECRET_KEY` — from https://clerk.com

### 3. Set up the database

```bash
npm run db:generate
npm run db:migrate
npm run db:seed
```

This seeds 4 sample teams, 2 fixtures, and sample bookmaker odds so the dashboard isn't empty on first run.

### 4. Run the app

```bash
npm run dev
```

Visit http://localhost:3000

## Pages

- `/` — Landing page
- `/dashboard` — All fixtures with win/draw/loss predictions
- `/matches/[id]` — Full match analysis (probabilities, BTTS, correct scores)
- `/bet-builder` — Daily best single/double/treble/accumulator by EV
- `/tournament` — Group standings by Elo rating
- `/live` — Live match scores (auto-refreshes every 30s)
- `/profile` — User saved bets (requires Clerk sign-in)
- `/settings` — Dark mode & notification preferences

## API Routes

- `GET /api/matches/[id]/analysis` — Prediction for a single match
- `POST /api/matches/[id]/explain` — Claude-generated explanation for a prediction
- `GET /api/scanner` — All positive-EV bookmaker opportunities across matches
- `GET /api/best-bets` — Best single/double/treble/accumulator ranked by EV

## Background Worker

```bash
cd apps/worker
npm install
npm run poll-odds
```

Run on a schedule (e.g. every 15 min via Railway cron) to:
1. Pull fresh bookmaker odds from The Odds API
2. Regenerate predictions for all scheduled matches

## Deployment

- **Frontend + API**: Deploy `apps/web` to Vercel, set env vars in project settings
- **Database**: Supabase Postgres — run `prisma migrate deploy` against it
- **Worker**: Deploy `apps/worker` to Railway with a cron schedule
- **Auth**: Create a Clerk application, add allowed origins for your domain

## Notes on the prediction model

The current model (`packages/engine/predict.ts`) blends an Elo-based win probability with a
Poisson goal model using xG/xGA and form. The `teamInputsFrom()` helpers in the API routes
currently use placeholder xG/xGA/form values — wire these up to real data feeds (injuries,
lineups, recent form, travel/rest) to improve accuracy. EV figures are model estimates, not
guarantees — treat this as a decision-support tool.
