import { db } from "../../../packages/db";
import { predictMatch, TeamInputs } from "../../../packages/engine/predict";

const ODDS_API_KEY = process.env.ODDS_API_KEY!;

export async function pollOdds() {
  const res = await fetch(
    `https://api.the-odds-api.com/v4/sports/soccer_fifa_world_cup/odds?apiKey=${ODDS_API_KEY}&regions=uk,eu&markets=h2h,totals,btts`
  );
  const data = await res.json();

  for (const event of data) {
    const match = await db.match.findFirst({
      where: {
        homeTeam: { name: event.home_team },
        awayTeam: { name: event.away_team },
      },
    });
    if (!match) continue;

    for (const bookmaker of event.bookmakers ?? []) {
      for (const market of bookmaker.markets ?? []) {
        for (const outcome of market.outcomes ?? []) {
          await db.odds.create({
            data: {
              matchId: match.id,
              bookmaker: bookmaker.key,
              market: market.key,
              selection: outcome.name,
              price: outcome.price,
            },
          });
        }
      }
    }
  }

  console.log(`Polled odds for ${data.length} events`);
}

export async function refreshPredictions() {
  const matches = await db.match.findMany({
    where: { status: "scheduled" },
    include: { homeTeam: true, awayTeam: true },
  });

  for (const match of matches) {
    const homeInputs: TeamInputs = {
      elo: match.homeTeam.eloRating ?? 1500,
      fifaRank: match.homeTeam.fifaRank ?? 50,
      squadValue: match.homeTeam.squadValue ?? 0,
      xg: 1.4,
      xga: 1.1,
      formScore: 0.5,
      restDays: 4,
    };
    const awayInputs: TeamInputs = {
      elo: match.awayTeam.eloRating ?? 1500,
      fifaRank: match.awayTeam.fifaRank ?? 50,
      squadValue: match.awayTeam.squadValue ?? 0,
      xg: 1.3,
      xga: 1.2,
      formScore: 0.5,
      restDays: 4,
    };

    const prediction = predictMatch(homeInputs, awayInputs);

    await db.prediction.create({
      data: {
        matchId: match.id,
        homeWinProb: prediction.homeWinProb,
        drawProb: prediction.drawProb,
        awayWinProb: prediction.awayWinProb,
        bttsProb: prediction.bttsProb,
        over25Prob: prediction.over25Prob,
        correctScores: prediction.correctScores,
        confidence: 0.7,
        modelVersion: "v1-poisson-elo",
      },
    });
  }

  console.log(`Refreshed predictions for ${matches.length} matches`);
}

// Entry point if run directly
if (require.main === module) {
  Promise.all([pollOdds(), refreshPredictions()])
    .then(() => process.exit(0))
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
