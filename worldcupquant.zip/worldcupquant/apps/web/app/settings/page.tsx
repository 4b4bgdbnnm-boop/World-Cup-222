"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function SettingsPage() {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);

  return (
    <div className="p-4 md:p-8 max-w-xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      <Card>
        <CardHeader>
          <CardTitle>Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="dark">Dark Mode</Label>
            <Switch
              id="dark"
              checked={darkMode}
              onCheckedChange={(v) => {
                setDarkMode(v);
                document.documentElement.classList.toggle("dark", v);
              }}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="notif">Notifications</Label>
            <Switch id="notif" checked={notifications} onCheckedChange={setNotifications} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
