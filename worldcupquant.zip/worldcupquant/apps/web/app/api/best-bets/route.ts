import { db } from "@/packages/db";
import { expectedValue } from "@/packages/engine/ev";
import { buildCombo, Leg } from "@/packages/engine/betBuilder";
import { NextResponse } from "next/server";

export async function GET() {
  const matches = await db.match.findMany({
    where: { status: "scheduled" },
    include: {
      odds: true,
      predictions: { take: 1, orderBy: { createdAt: "desc" } },
      homeTeam: true,
      awayTeam: true,
    },
  });

  type Candidate = {
    matchId: string;
    label: string;
    market: string;
    selection: string;
    prob: number;
    odds: number;
    ev: number;
  };
  const singles: Candidate[] = [];

  for (const m of matches) {
    const pred = m.predictions[0];
    if (!pred) continue;
    const probMap: Record<string, number> = {
      "1": pred.homeWinProb,
      X: pred.drawProb,
      "2": pred.awayWinProb,
      BTTS_YES: pred.bttsProb,
      "OVER_2.5": pred.over25Prob,
    };

    for (const o of m.odds) {
      const prob = probMap[o.selection];
      if (!prob) continue;
      const ev = expectedValue(prob, o.price);
      if (ev > 0) {
        singles.push({
          matchId: m.id,
          label: `${m.homeTeam.name} vs ${m.awayTeam.name}`,
          market: o.market,
          selection: o.selection,
          prob,
          odds: o.price,
          ev,
        });
      }
    }
  }

  singles.sort((a, b) => b.ev - a.ev);

  const bestSingle = singles[0] ?? null;
  const bestDoubleLegs = pickTopN(singles, 2);
  const bestTrebleLegs = pickTopN(singles, 3);
  const bestAccaLegs = pickTopN(singles, 5);

  return NextResponse.json({
    bestSingle,
    bestDouble: bestDoubleLegs ? buildCombo(bestDoubleLegs) : null,
    bestTreble: bestTrebleLegs ? buildCombo(bestTrebleLegs) : null,
    bestAccumulator: bestAccaLegs ? buildCombo(bestAccaLegs) : null,
  });
}

function pickTopN(singles: any[], n: number): Leg[] | null {
  const seen = new Set<string>();
  const legs: Leg[] = [];
  for (const s of singles) {
    if (seen.has(s.matchId)) continue;
    legs.push({ market: s.market, selection: s.selection, prob: s.prob, odds: s.odds });
    seen.add(s.matchId);
    if (legs.length === n) break;
  }
  return legs.length === n ? legs : null;
}
