import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic();

export async function POST(req: Request) {
  const { match, prediction, stats } = await req.json();

  const prompt = `You are a football analyst. Given this data, explain the prediction in 3 parts:
1. Why this outcome was selected (2-3 sentences)
2. Supporting statistics (bullet points)
3. Key risks to this prediction (bullet points)

Match: ${match.homeTeam.name} vs ${match.awayTeam.name}
Prediction: Home ${prediction.homeWinProb}, Draw ${prediction.drawProb}, Away ${prediction.awayWinProb}
BTTS: ${prediction.bttsProb}, Over 2.5: ${prediction.over25Prob}
Stats context: ${JSON.stringify(stats ?? {})}

Respond as JSON only: {"reasoning": "", "stats": [], "risks": [], "confidence": 0-1}`;

  const res = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 600,
    messages: [{ role: "user", content: prompt }],
  });

  const text = res.content.find((c) => c.type === "text")?.text ?? "{}";
  const clean = text.replace(/```json|```/g, "").trim();

  try {
    return NextResponse.json(JSON.parse(clean));
  } catch {
    return NextResponse.json({ reasoning: text, stats: [], risks: [], confidence: 0.5 });
  }
}
