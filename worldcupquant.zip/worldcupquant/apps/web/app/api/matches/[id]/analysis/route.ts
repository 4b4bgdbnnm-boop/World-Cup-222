import { db } from "@/packages/db";
import { predictMatch, TeamInputs } from "@/packages/engine/predict";
import { NextResponse } from "next/server";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const match = await db.match.findUnique({
    where: { id: params.id },
    include: { homeTeam: true, awayTeam: true, odds: true, predictions: true },
  });
  if (!match) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const prediction = predictMatch(teamInputsFrom(match.homeTeam), teamInputsFrom(match.awayTeam));

  return NextResponse.json({ match, prediction });
}

function teamInputsFrom(team: any): TeamInputs {
  return {
    elo: team.eloRating ?? 1500,
    fifaRank: team.fifaRank ?? 50,
    squadValue: team.squadValue ?? 0,
    xg: 1.4,
    xga: 1.1,
    formScore: 0.5,
    restDays: 4,
  };
}
