import { db } from "@/packages/db";
import { scanMarket } from "@/packages/engine/ev";
import { NextResponse } from "next/server";

export async function GET() {
  const matches = await db.match.findMany({
    where: { status: "scheduled" },
    include: {
      odds: true,
      homeTeam: true,
      awayTeam: true,
      predictions: { take: 1, orderBy: { createdAt: "desc" } },
    },
  });

  const opportunities: any[] = [];

  for (const match of matches) {
    const pred = match.predictions[0];
    if (!pred) continue;

    const probMap: Record<string, number> = {
      "1": pred.homeWinProb,
      X: pred.drawProb,
      "2": pred.awayWinProb,
      BTTS_YES: pred.bttsProb,
      "OVER_2.5": pred.over25Prob,
    };

    const grouped = groupByMarketSelection(match.odds);

    for (const [key, bookOdds] of Object.entries(grouped)) {
      const [market, selection] = key.split("|");
      const trueProb = probMap[selection];
      if (!trueProb) continue;

      const found = scanMarket(match.id, market, selection, bookOdds, trueProb);
      opportunities.push(
        ...found.map((o) => ({
          ...o,
          matchLabel: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
        }))
      );
    }
  }

  opportunities.sort((a, b) => b.ev - a.ev);
  return NextResponse.json({ opportunities: opportunities.slice(0, 50) });
}

function groupByMarketSelection(odds: any[]) {
  const map: Record<string, { bookmaker: string; price: number }[]> = {};
  for (const o of odds) {
    const key = `${o.market}|${o.selection}`;
    map[key] = map[key] || [];
    map[key].push({ bookmaker: o.bookmaker, price: o.price });
  }
  return map;
}
