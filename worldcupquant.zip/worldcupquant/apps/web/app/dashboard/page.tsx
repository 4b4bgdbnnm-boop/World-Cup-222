import { db } from "@/packages/db";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default async function DashboardPage() {
  const matches = await db.match.findMany({
    where: { status: { in: ["scheduled", "live"] } },
    include: {
      homeTeam: true,
      awayTeam: true,
      predictions: { take: 1, orderBy: { createdAt: "desc" } },
    },
    orderBy: { kickoff: "asc" },
    take: 20,
  });

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">World Cup Dashboard</h1>

      {matches.length === 0 && (
        <p className="text-muted-foreground">No upcoming fixtures found. Seed the database to get started.</p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {matches.map((m) => {
          const pred = m.predictions[0];
          return (
            <Link key={m.id} href={`/matches/${m.id}`}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">
                    {m.homeTeam.name} vs {m.awayTeam.name}
                  </CardTitle>
                  <Badge variant={m.status === "live" ? "destructive" : "secondary"}>{m.status}</Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground mb-2">
                    {new Date(m.kickoff).toLocaleString()}
                  </p>
                  {pred && (
                    <div className="grid grid-cols-3 gap-2 text-center text-sm">
                      <div>
                        <div className="font-bold">{(pred.homeWinProb * 100).toFixed(0)}%</div>
                        <div className="text-xs text-muted-foreground">Home</div>
                      </div>
                      <div>
                        <div className="font-bold">{(pred.drawProb * 100).toFixed(0)}%</div>
                        <div className="text-xs text-muted-foreground">Draw</div>
                      </div>
                      <div>
                        <div className="font-bold">{(pred.awayWinProb * 100).toFixed(0)}%</div>
                        <div className="text-xs text-muted-foreground">Away</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
