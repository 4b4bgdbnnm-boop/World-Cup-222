import { auth, currentUser } from "@clerk/nextjs";
import { db } from "@/packages/db";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function ProfilePage() {
  const { userId } = auth();
  const user = await currentUser();
  if (!userId) return <div className="p-8">Please sign in.</div>;

  const savedBets = await db.savedBet.findMany({
    where: { userId },
    take: 10,
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-4 md:p-8 max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Profile</h1>
      <Card>
        <CardHeader>
          <CardTitle>
            {user?.firstName} {user?.lastName}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          {user?.emailAddresses[0]?.emailAddress}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Saved Bets</CardTitle>
        </CardHeader>
        <CardContent>
          {savedBets.length === 0 ? (
            <p className="text-sm text-muted-foreground">No saved bets yet.</p>
          ) : (
            <ul className="space-y-2">
              {savedBets.map((b) => (
                <li key={b.id} className="text-sm border-b pb-1">
                  {b.notes ?? "Saved bet"} — {new Date(b.createdAt).toLocaleDateString()}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
