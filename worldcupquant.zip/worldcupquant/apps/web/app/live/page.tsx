import { db } from "@/packages/db";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const revalidate = 30;

export default async function LivePage() {
  const matches = await db.match.findMany({
    where: { status: "live" },
    include: { homeTeam: true, awayTeam: true },
  });

  if (matches.length === 0) {
    return <div className="p-8 text-center text-muted-foreground">No live matches right now.</div>;
  }

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">Live Matches</h1>
      {matches.map((m) => (
        <Card key={m.id}>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>
              {m.homeTeam.name} {m.homeScore} - {m.awayScore} {m.awayTeam.name}
            </CardTitle>
            <Badge variant="destructive">LIVE</Badge>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">{m.stage}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
