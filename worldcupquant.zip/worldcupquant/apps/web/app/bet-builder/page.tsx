import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

async function getBestBets() {
  const base = process.env.NEXT_PUBLIC_URL ?? "http://localhost:3000";
  const res = await fetch(`${base}/api/best-bets`, { cache: "no-store" });
  return res.json();
}

export default async function BetBuilderPage() {
  const data = await getBestBets();

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Daily Best Bets</h1>

      {!data.bestSingle && (
        <p className="text-muted-foreground">
          No positive EV opportunities found yet. Once odds and predictions are populated, they'll appear here.
        </p>
      )}

      {data.bestSingle && (
        <BetCard title="Best Single" ev={data.bestSingle.ev} prob={data.bestSingle.prob} odds={data.bestSingle.odds}>
          <p className="text-sm">
            {data.bestSingle.label} — {data.bestSingle.market} / {data.bestSingle.selection}
          </p>
        </BetCard>
      )}

      {data.bestDouble && (
        <BetCard title="Best Double" ev={data.bestDouble.ev} prob={data.bestDouble.combinedProb} odds={data.bestDouble.combinedOdds}>
          <LegsList legs={data.bestDouble.legs} />
        </BetCard>
      )}

      {data.bestTreble && (
        <BetCard title="Best Treble" ev={data.bestTreble.ev} prob={data.bestTreble.combinedProb} odds={data.bestTreble.combinedOdds}>
          <LegsList legs={data.bestTreble.legs} />
        </BetCard>
      )}

      {data.bestAccumulator && (
        <BetCard
          title="Best Accumulator"
          ev={data.bestAccumulator.ev}
          prob={data.bestAccumulator.combinedProb}
          odds={data.bestAccumulator.combinedOdds}
        >
          <LegsList legs={data.bestAccumulator.legs} />
        </BetCard>
      )}
    </div>
  );
}

function BetCard({ title, ev, prob, odds, children }: any) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{title}</CardTitle>
        <Badge variant={ev > 0.1 ? "default" : "secondary"}>EV +{(ev * 100).toFixed(1)}%</Badge>
      </CardHeader>
      <CardContent className="space-y-2">
        {children}
        <div className="flex justify-between text-sm text-muted-foreground pt-2 border-t">
          <span>Probability: {(prob * 100).toFixed(1)}%</span>
          <span>Odds: {odds.toFixed(2)}</span>
        </div>
      </CardContent>
    </Card>
  );
}

function LegsList({ legs }: { legs: any[] }) {
  return (
    <ul className="space-y-1">
      {legs.map((l, i) => (
        <li key={i} className="text-sm flex justify-between">
          <span>
            {l.market} — {l.selection}
          </span>
          <span className="text-muted-foreground">@{l.odds.toFixed(2)}</span>
        </li>
      ))}
    </ul>
  );
}
