import "./globals.css";
import { ClerkProvider, SignedIn, SignedOut, UserButton, SignInButton } from "@clerk/nextjs";
import Link from "next/link";

export const metadata = {
  title: "WorldCupQuant AI",
  description: "AI-powered FIFA World Cup betting intelligence platform",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body className="min-h-screen bg-background font-sans">
          <header className="border-b px-4 py-3 flex items-center justify-between">
            <Link href="/dashboard" className="font-bold text-lg">
              WorldCupQuant AI
            </Link>
            <nav className="hidden md:flex gap-4 text-sm">
              <Link href="/dashboard">Dashboard</Link>
              <Link href="/live">Live</Link>
              <Link href="/bet-builder">Bet Builder</Link>
              <Link href="/tournament">Tournament</Link>
              <Link href="/profile">Profile</Link>
              <Link href="/settings">Settings</Link>
            </nav>
            <div>
              <SignedIn>
                <UserButton />
              </SignedIn>
              <SignedOut>
                <SignInButton />
              </SignedOut>
            </div>
          </header>
          <main>{children}</main>
        </body>
      </html>
    </ClerkProvider>
  );
}
