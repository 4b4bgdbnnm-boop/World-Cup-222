import { db } from "@/packages/db";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function TournamentPage() {
  const teams = await db.team.findMany({ orderBy: { eloRating: "desc" } });
  const groups = groupBy(teams, (t) => t.group ?? "Unassigned");

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Tournament Overview</h1>

      {teams.length === 0 && (
        <p className="text-muted-foreground">No teams found. Seed the database to populate groups.</p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {Object.entries(groups).map(([group, members]) => (
          <Card key={group}>
            <CardHeader>
              <CardTitle className="text-sm">Group {group}</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-1 text-sm">
                {members.map((t, i) => (
                  <li key={t.id} className="flex justify-between">
                    <span>
                      {i + 1}. {t.name}
                    </span>
                    <span className="text-muted-foreground">{t.eloRating?.toFixed(0) ?? "-"}</span>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function groupBy<T>(arr: T[], fn: (item: T) => string) {
  return arr.reduce((acc, item) => {
    const key = fn(item);
    (acc[key] = acc[key] || []).push(item);
    return acc;
  }, {} as Record<string, T[]>);
}
