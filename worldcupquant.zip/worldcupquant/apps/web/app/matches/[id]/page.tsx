import { db } from "@/packages/db";
import { predictMatch } from "@/packages/engine/predict";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default async function MatchPage({ params }: { params: { id: string } }) {
  const match = await db.match.findUnique({
    where: { id: params.id },
    include: { homeTeam: true, awayTeam: true, odds: true },
  });
  if (!match) return <div className="p-8">Match not found</div>;

  const prediction = predictMatch(
    {
      elo: match.homeTeam.eloRating ?? 1500,
      fifaRank: match.homeTeam.fifaRank ?? 50,
      squadValue: match.homeTeam.squadValue ?? 0,
      xg: 1.4,
      xga: 1.1,
      formScore: 0.5,
      restDays: 4,
    },
    {
      elo: match.awayTeam.eloRating ?? 1500,
      fifaRank: match.awayTeam.fifaRank ?? 50,
      squadValue: match.awayTeam.squadValue ?? 0,
      xg: 1.3,
      xga: 1.2,
      formScore: 0.5,
      restDays: 4,
    }
  );

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">
        {match.homeTeam.name} vs {match.awayTeam.name}
      </h1>
      <p className="text-muted-foreground">
        {new Date(match.kickoff).toLocaleString()} · {match.stage}
      </p>

      <Card>
        <CardHeader>
          <CardTitle>Match Outcome Probability</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <ProbRow label={match.homeTeam.name} value={prediction.homeWinProb} />
          <ProbRow label="Draw" value={prediction.drawProb} />
          <ProbRow label={match.awayTeam.name} value={prediction.awayWinProb} />
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">BTTS</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold">
            {(prediction.bttsProb * 100).toFixed(0)}%
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Over 2.5 Goals</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-bold">
            {(prediction.over25Prob * 100).toFixed(0)}%
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Most Likely Scores</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-2">
          {prediction.correctScores.map((cs) => (
            <div key={cs.score} className="text-center border rounded p-2">
              <div className="font-bold">{cs.score}</div>
              <div className="text-xs text-muted-foreground">{(cs.prob * 100).toFixed(1)}%</div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function ProbRow({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span>{label}</span>
        <span className="font-bold">{(value * 100).toFixed(1)}%</span>
      </div>
      <Progress value={value * 100} />
    </div>
  );
}
