import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center py-24 px-4 text-center space-y-6">
      <h1 className="text-4xl md:text-6xl font-bold">WorldCupQuant AI</h1>
      <p className="text-lg text-muted-foreground max-w-xl">
        AI-powered World Cup match analysis, positive EV betting opportunities, and smart bet
        builders — all in one platform.
      </p>
      <div className="flex gap-4">
        <Link href="/dashboard">
          <Button size="lg">Open Dashboard</Button>
        </Link>
        <Link href="/bet-builder">
          <Button size="lg" variant="outline">
            Today's Best Bets
          </Button>
        </Link>
      </div>
    </div>
  );
}
