import { expectedValue } from "./ev";

export interface Leg {
  market: string;
  selection: string;
  prob: number;
  odds: number;
}

function round(n: number): number {
  return Math.round(n * 1000) / 1000;
}

export function buildCombo(legs: Leg[]) {
  const combinedProb = legs.reduce((acc, l) => acc * l.prob, 1);
  const combinedOdds = legs.reduce((acc, l) => acc * l.odds, 1);
  const ev = expectedValue(combinedProb, combinedOdds);
  const riskScore = 1 - combinedProb;
  return {
    legs,
    combinedProb: round(combinedProb),
    combinedOdds: round(combinedOdds),
    ev: round(ev),
    riskScore: round(riskScore),
  };
}

export function classifyBuilder(allCandidates: Leg[][]) {
  const scored = allCandidates.map(buildCombo);
  return {
    safest: scored.filter((s) => s.riskScore < 0.3).sort((a, b) => b.combinedProb - a.combinedProb)[0],
    highestEV: [...scored].sort((a, b) => b.ev - a.ev)[0],
    riskReward: [...scored].sort((a, b) => b.ev / b.riskScore - a.ev / a.riskScore)[0],
    aggressive: scored.filter((s) => s.legs.length >= 4).sort((a, b) => b.ev - a.ev)[0],
  };
}
