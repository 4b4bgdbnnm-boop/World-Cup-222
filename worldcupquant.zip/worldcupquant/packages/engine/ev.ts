export function impliedProbability(decimalOdds: number): number {
  return 1 / decimalOdds;
}

export function removeVig(impliedProbs: number[]): number[] {
  const total = impliedProbs.reduce((a, b) => a + b, 0);
  return impliedProbs.map((p) => p / total);
}

export function expectedValue(trueProb: number, decimalOdds: number, stake = 1): number {
  const profit = (decimalOdds - 1) * stake;
  return trueProb * profit - (1 - trueProb) * stake;
}

export function edgePercent(trueProb: number, bookOdds: number): number {
  const fairOdds = 1 / trueProb;
  return ((bookOdds - fairOdds) / fairOdds) * 100;
}

export interface ScannedMarket {
  matchId: string;
  market: string;
  selection: string;
  bookmaker: string;
  bookOdds: number;
  trueProb: number;
  fairOdds: number;
  ev: number;
  edge: number;
}

export function scanMarket(
  matchId: string,
  market: string,
  selection: string,
  bookmakerOdds: { bookmaker: string; price: number }[],
  trueProb: number
): ScannedMarket[] {
  return bookmakerOdds
    .map((b) => ({
      matchId,
      market,
      selection,
      bookmaker: b.bookmaker,
      bookOdds: b.price,
      trueProb,
      fairOdds: 1 / trueProb,
      ev: expectedValue(trueProb, b.price),
      edge: edgePercent(trueProb, b.price),
    }))
    .filter((r) => r.ev > 0)
    .sort((a, b) => b.ev - a.ev);
}
