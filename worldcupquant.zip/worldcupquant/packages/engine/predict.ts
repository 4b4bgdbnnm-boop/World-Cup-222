export interface TeamInputs {
  elo: number;
  fifaRank: number;
  squadValue: number;
  xg: number;
  xga: number;
  formScore: number;
  restDays: number;
}

export function eloWinProb(eloA: number, eloB: number, homeAdv = 60): number {
  return 1 / (1 + Math.pow(10, (eloB - (eloA + homeAdv)) / 400));
}

function factorial(n: number): number {
  return n <= 1 ? 1 : n * factorial(n - 1);
}

function poissonPMF(k: number, lambda: number): number {
  return (Math.pow(lambda, k) * Math.exp(-lambda)) / factorial(k);
}

function round(n: number): number {
  return Math.round(n * 1000) / 1000;
}

export interface PredictionResult {
  homeWinProb: number;
  drawProb: number;
  awayWinProb: number;
  bttsProb: number;
  over25Prob: number;
  correctScores: { score: string; prob: number }[];
}

export function predictMatch(home: TeamInputs, away: TeamInputs): PredictionResult {
  const eloProb = eloWinProb(home.elo, away.elo);

  const homeLambda =
    (home.xg * 0.5 + away.xga * 0.5) * (1 + (home.formScore - away.formScore) * 0.05);
  const awayLambda =
    (away.xg * 0.5 + home.xga * 0.5) * (1 + (away.formScore - home.formScore) * 0.05);

  const maxGoals = 6;
  let homeWin = 0,
    draw = 0,
    awayWin = 0,
    btts = 0,
    over25 = 0;
  const correctScores: { score: string; prob: number }[] = [];

  for (let h = 0; h <= maxGoals; h++) {
    for (let a = 0; a <= maxGoals; a++) {
      const p = poissonPMF(h, homeLambda) * poissonPMF(a, awayLambda);
      if (h > a) homeWin += p;
      else if (h === a) draw += p;
      else awayWin += p;
      if (h > 0 && a > 0) btts += p;
      if (h + a > 2) over25 += p;
      correctScores.push({ score: `${h}-${a}`, prob: p });
    }
  }

  const total = homeWin + draw + awayWin;
  const blendedHome = (homeWin / total) * 0.6 + eloProb * 0.4;
  const blendedDraw = (draw / total) * 0.6 + 0.2 * 0.4;
  const blendedAway = 1 - blendedHome - blendedDraw;

  return {
    homeWinProb: round(blendedHome),
    drawProb: round(blendedDraw),
    awayWinProb: round(blendedAway),
    bttsProb: round(btts),
    over25Prob: round(over25),
    correctScores: correctScores
      .sort((a, b) => b.prob - a.prob)
      .slice(0, 6)
      .map((c) => ({ ...c, prob: round(c.prob) })),
  };
}
