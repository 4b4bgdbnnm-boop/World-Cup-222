import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const argentina = await db.team.create({
    data: { name: "Argentina", group: "A", fifaRank: 1, eloRating: 2100, squadValue: 1200 },
  });
  const france = await db.team.create({
    data: { name: "France", group: "A", fifaRank: 2, eloRating: 2090, squadValue: 1400 },
  });
  const brazil = await db.team.create({
    data: { name: "Brazil", group: "B", fifaRank: 3, eloRating: 2080, squadValue: 1350 },
  });
  const england = await db.team.create({
    data: { name: "England", group: "B", fifaRank: 4, eloRating: 2050, squadValue: 1300 },
  });

  const match1 = await db.match.create({
    data: {
      homeTeamId: argentina.id,
      awayTeamId: france.id,
      kickoff: new Date(Date.now() + 1000 * 60 * 60 * 24),
      group: "A",
      stage: "Group Stage",
      status: "scheduled",
    },
  });

  const match2 = await db.match.create({
    data: {
      homeTeamId: brazil.id,
      awayTeamId: england.id,
      kickoff: new Date(Date.now() + 1000 * 60 * 60 * 48),
      group: "B",
      stage: "Group Stage",
      status: "scheduled",
    },
  });

  // Sample odds
  await db.odds.createMany({
    data: [
      { matchId: match1.id, bookmaker: "Bet365", market: "h2h", selection: "1", price: 2.3 },
      { matchId: match1.id, bookmaker: "Bet365", market: "h2h", selection: "X", price: 3.4 },
      { matchId: match1.id, bookmaker: "Bet365", market: "h2h", selection: "2", price: 3.1 },
      { matchId: match1.id, bookmaker: "Pinnacle", market: "h2h", selection: "1", price: 2.45 },
      { matchId: match1.id, bookmaker: "Bet365", market: "totals", selection: "OVER_2.5", price: 1.95 },
      { matchId: match1.id, bookmaker: "Bet365", market: "btts", selection: "BTTS_YES", price: 1.75 },

      { matchId: match2.id, bookmaker: "Bet365", market: "h2h", selection: "1", price: 1.9 },
      { matchId: match2.id, bookmaker: "Bet365", market: "h2h", selection: "X", price: 3.6 },
      { matchId: match2.id, bookmaker: "Bet365", market: "h2h", selection: "2", price: 4.2 },
    ],
  });

  console.log("Seed complete:", { match1: match1.id, match2: match2.id });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
